//export const API_URL = 'http://localhost:8080';
export const API_URL = 'http://backendjogodaonca-env.eba-d9srpszz.us-east-1.elasticbeanstalk.com';
